package com.example.simpleuifinal;

public class Constants {
	public static final String TABLE_NAME = "MessageForHW3";

}
